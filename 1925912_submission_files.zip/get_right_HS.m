function Right_HS=get_right_HS(FC)
    Right_HS=[FC(181:360,181:360,:)];
end
