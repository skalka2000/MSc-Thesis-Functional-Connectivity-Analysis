function Left_HS=get_left_HS(FC)
    Left_HS=FC(1:180,1:180,:);
end
